#include "IRifle.h"
#include "CRifle.h"