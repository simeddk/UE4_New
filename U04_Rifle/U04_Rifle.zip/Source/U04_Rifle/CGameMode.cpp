#include "CGameMode.h"

ACGameMode::ACGameMode()
{

}