#pragma once

#include "CoreMinimal.h"
#include "01_Spawn/C02_MeshActor.h"
#include "C02_MeshActor_Sphere.generated.h"

UCLASS()
class U04_RIFLE_API AC02_MeshActor_Sphere : public AC02_MeshActor
{
	GENERATED_BODY()

public:
	AC02_MeshActor_Sphere();
};
