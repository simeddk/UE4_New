#include "C01_ActorOverap.h"

AC01_ActorOverap::AC01_ActorOverap()
{


}

void AC01_ActorOverap::BeginPlay()
{
	Super::BeginPlay();
	
}

